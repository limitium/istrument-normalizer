### Routing storage

Routring rules must be stored under `GBA ref` in `GBA_VALUE_LIST` table.

*@TBD:* insure that GBA_INSTANCE column isn't used in GBA side

Under `GBA refshared` new view `INSTRUMENT_METADATA` must be made based on current tables `EQUITIES` and `COUNTRIES` and combines ric suffix as a primary key with global primary exchange and country

| GBA_INSTANCE | GBA_ENTITY  | FIELD_NAME  | VALUE    | VALUE_TYPE |
|--------------|-------------|-------------|----------|------------|
| ERA-EMEA     | ERARouting  | {rule_name} | {format} | String     |

### Routing format

`;` is delimeter between rule parts and acts as logical `AND`

#### List of attributes for routing

* CRDS
* ExchangeCode
* CountryCode

#### Possible value types for attributes

* `=QWE` - equals to single value
* `=QWE,ASD` - in set of values

##### Rule examples

* ExchangeCode=NYS,PBT;CountryCode=US
* CRDS=ASDZXC,QWERTY,CVBDFG;CountryCode=FR
