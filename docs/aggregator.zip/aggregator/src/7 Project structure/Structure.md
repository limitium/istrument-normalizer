### Project has 3 main modules:

* `aggregator` - Statefull component with routing and aggregation
* `docs` - Documentation
* `router` - Shared artifact with router bean, must be java 8 compatible
* `kafka-connect` - S2K and K2S kafka connectors
* `topicctl` - Kafka topics DDL