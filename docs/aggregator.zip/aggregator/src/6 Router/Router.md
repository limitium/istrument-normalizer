## Shared router bean

```java

public class Router {
    /**
     * Loads rules and instrument metadata into Router
     *
     * @param rules loaded from GBA_VALUES from GBA ref
     * @param instrumentMeta map with ric suffix as a key and instrument data as a value
     */
    public Router(List<String> rules, Map<String, InstrumentMeta> instrumentMeta){

    }

    /**
     * Checks each report against loaded rules
     *
     * @param report ATM8
     * @param ric
     * @param crds
     * @return
     */
    boolean isERAEligible(AXExecutionReport report, String ric, String crds){

    }

    /**
     * Checks each report against loaded rules
     *
     * @param status ATMG
     * @param ric
     * @param crds
     * @return
     */
    boolean isERAEligible(AXOrderStatus status, String ric, String crds){

    }

    static class InstrumentMeta{
        String mic;
        String countryCode;
    }
}
```