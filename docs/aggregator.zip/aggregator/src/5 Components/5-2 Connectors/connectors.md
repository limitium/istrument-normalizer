`S2K` - binary copier from solace to kafka, must takes `RIC` from the solace topic and use it as a `key` for the kafka topic

`K2S` -  binary copier from kafka to solace, w\o additional logic