`ERA` at init phase loads static data from `GBA refshared` and routing defenitions from `GBA ref`. 


### Aggregates steam

| Netting key            | Aggregate id | Agg refId | Agg type | Is active | Execution id  | Exec refId | Exec type | Created time |
|------------------------|--------------|-----------|----------|-----------|---------------|------------|-----------|--------------|
|                        |          444 |       111 | amend    | false     |               |            |           | 14            |
|                        |              |           |          |           | 444           | 111        | cancel    | 13           |
| DCA;123;NYC;12.02.2004 |          333 |           | new      | true      |               |            |           | 12           |
|                        |              |           |          |           | 335           |            | new       | 11           |
|                        |              |           |          |           | 334           |            | new       | 10           |
|                        |              |           |          |           | 333           |            | new       | 9            |
|                        |          222 |           | new      | false     |               |            |           | 8            |
|                        |              |           |          |           | 224           |            | new       | 7            |
|                        |              |           |          |           | 223           |            | new       | 6            |
|                        |              |           |          |           | 222           |            | new       | 5            |
|                        |          111 |           | new      | false     |               |            |           | 4            |
|                        |              |           |          |           | 113           |            | new       | 3            |
|                        |              |           |          |           | 112           |            | new       | 2            |
|                        |              |           |          |           | 111           |            | new       | 1            |
