`ERA` at init phase loads static data from `GBA refshared` and routing defenitions from `GBA ref`. 

TBD: define aggragate and chain of aggragtes