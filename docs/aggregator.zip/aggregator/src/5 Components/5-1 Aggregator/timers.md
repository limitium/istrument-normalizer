## Timers

Timers must be defined as `CountryCode` + `ProductType` and `trigger time`. Timers acts as internal `send triggers`.

Timers must:
* Be suspendable from external call - kafka message
* Be triggered manually from extarnal call - kafma message

Should be implemented as additional KSProcessor in the topology and be separated from the main processor by a kafka topic.
