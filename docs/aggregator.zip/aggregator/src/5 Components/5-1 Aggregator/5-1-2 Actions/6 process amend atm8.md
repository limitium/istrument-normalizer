## Process amend ATM8

If amend hit a sent aggregator, then `unnet` previous execuiton,`net` amended and rebuild all links is required before send.
Otherwise `unnet` and `net` from active aggregator.