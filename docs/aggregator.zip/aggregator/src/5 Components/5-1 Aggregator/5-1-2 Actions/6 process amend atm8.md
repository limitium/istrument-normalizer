## Process amend ATM8

unnet old
net new 
to active is possbile (no negs) or to released 

check agg state

tbd action diag