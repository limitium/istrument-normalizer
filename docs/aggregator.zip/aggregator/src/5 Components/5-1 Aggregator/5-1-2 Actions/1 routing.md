## Routing

* tbd how to reload rules (synch with BIR is impossble)
* tbd how to run incoming object over set of defined rules

