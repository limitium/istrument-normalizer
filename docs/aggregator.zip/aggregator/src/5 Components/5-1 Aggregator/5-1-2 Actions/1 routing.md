## Routing

If `RIC` doesn't have `RIC suffix` message will be skipped.



