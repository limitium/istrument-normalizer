## Process process new ATM8

create
net 
check agg state

tbd action diag