## Process process new ATM8

Basic aggreation into active aggregator, defined by `netting criteria`.