## Netting

### Netting key calculation

`NettingKey` actually uniquely identifies an `Order` in `GBA` and calculated based on `NettingCriteria` definition wich is hardcoded

```java 
String nettingKey = String.format("%s;%s;%s",incomingReport.getSrcSysId():getSourceSystem(),incomingReport.getOrderId(),incomingReport.getTradeDateStr());
```

### Net/Unnet ATM8 to aggregate

#### Create aggragate based on ATM8

Copy fields vs zeroing

#### Net ATM8 to aggregate

tbd: netting w/o amt field
commisions to abs?
repeatings

#### Unnet ATM8 to aggregate



