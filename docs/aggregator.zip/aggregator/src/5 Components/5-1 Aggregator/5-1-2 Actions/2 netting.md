## Netting

### Netting key calculation

`NettingKey` actually uniquely identifies an `Order` under `Last market` in `GBA` and calculated based on `NettingCriteria` definition wich is hardcoded

```java 
String nettingKey = String.format("%s;%s;%s;%s",
        incomingReport.hasSrcSysId()?incomingReportincomingReport.getSrcSysId():getSourceSystem(),
        incomingReport.getOrderId(),
        incomingReport.getLastMkt(),
        incomingReport.getTradeDateStr()
    );
```

### Net/Unnet ATM8 to aggregate



Aggregatable fileds:
* qty
* price
* commission *if commissionType == ABSOLUTE*
  *  `CommissionDataGrpList`, research, exec and soft commissions groups. 

#### Create aggragate based on ATM8

All fields except aggregatable fields are copied as it is, aggregatable fields must be set to 0

#### Net ATM8 to aggregate

```java
    aggregate.price = (aggregate.qty * aggreagte.price + atm8.qty * atm8.price) / (aggregate.qty + atm8.qty);
    aggregate.qty += atm8.qty;
    if(atm8.commType == 3 /*ABSOLUTE*/){
        aggregate.commission += atm8.commission;ActiveAggregateStore.get(nettingKey)
    }
```

#### Unnet ATM8 to aggregate

```java
    aggregate.price = (aggregate.qty * aggreagte.price - atm8.qty * atm8.price) / (aggregate.qty - atm8.qty);
    aggregate.qty -= atm8.qty;
    if(atm8.commType == 3 /*ABSOLUTE*/){
        aggregate.commission -= atm8.commission;
    }
```

