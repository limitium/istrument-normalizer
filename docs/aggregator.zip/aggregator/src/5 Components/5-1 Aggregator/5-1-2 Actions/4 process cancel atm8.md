## Process cancel ATM8

If cancel hit a sent aggregator, then `unnet` previous execution and rebuild all links is required before send.
Otherwise `unnet` from active aggregator.