## Process cancel ATM8

unnet old
check agg state
to active is possbile (no negs) or to released 

tbd action diag