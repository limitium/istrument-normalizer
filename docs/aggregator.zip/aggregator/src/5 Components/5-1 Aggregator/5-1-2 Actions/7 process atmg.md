## Process ATMG

`Order updates` acts as a `send trigger` for the current `active aggregator` and go passthrue