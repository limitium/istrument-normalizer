## Process ATMG

aggregate release 
ATMG send

tbd action diag