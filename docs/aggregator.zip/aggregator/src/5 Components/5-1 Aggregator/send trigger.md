### Send tirggers

Differnet events that triggers active aggregators to be sent and be moved from `ActiveAggregateStore` to `SentAggregateStore`

* MaxAggregatedExecutions - triggers if number of aggreagted executions in active aggragator more than defined value
* MaxAggregateAwaitTimeout - triggers if active aggregate isn't updated more than defined value
* ATMG - Order updates trigger active aggreagate
* Timer - Bussines specific trigger