### Instrument metadata view

Under `GBA refshared` new view `INSTRUMENT_METADATA` must be made based on current tables `EQUITIES` and `COUNTRIES` and combines ric suffix as a primary key with global primary exchange and country

| RIC_SUFFIX | MIC  | COUNTRY_CODE |
|------------|------|--------------|
| N          | XNYC | US           |
| F          | XFRA | FR           |

TBD: move from MIC to EXCHANGE_CODE and from COUNTRY_CODE to COUNTRY_CODE_3