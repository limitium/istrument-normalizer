ERA - single service application based on KSCore. For bridging between kafka and solace brokers Kafka-connect is used.

