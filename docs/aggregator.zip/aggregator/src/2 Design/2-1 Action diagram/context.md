Functionally, the entire project can be described with the following high-level diagram:
